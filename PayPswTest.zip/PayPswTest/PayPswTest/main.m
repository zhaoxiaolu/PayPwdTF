//
//  main.m
//  PayPswTest
//
//  Created by scott on 16/12/6.
//  Copyright © 2016年 scott. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
