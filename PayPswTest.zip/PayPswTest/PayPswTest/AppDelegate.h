//
//  AppDelegate.h
//  PayPswTest
//
//  Created by scott on 16/12/6.
//  Copyright © 2016年 scott. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

